classdef ClassificationEvaluation
methods(Static=true)
    function [precision, sensitivity, specificity] = checkPrediction(sortedScoresAll, sortedIndicesAll, numPredictions, targetItemSet)
%          Description:
%              Calculate the expected precision, sensitivity and specificity if one were to predict (or identify as positives) numPredictions items using scores provided in sortedScoresAll.
%              The logic is specified in the following:
%              'AUC from Scores' by nAgarAjan naTarAjan and vishvAs vAsuki. http://userweb.cs.utexas.edu/~vvasuki/work/statistics/AUCFromScores/AUCFromScores.pdf
%          WARNING: Minimal error checking. Please send valid inputs :-).
%          Input:
%              sortedScoresAll: vector. The sorted scores assigned to all items of interest.
%              sortedIndicesAll: vector. The indices of items corresponding to scores in sortedScoresAll.
%              numPredictions: scalar. The number of predictions to be made using the score vector.
%              targetItemSet: logical vector. ith element is 1 if the ith item is in the target set, and 0 otherwise.
%          Assumption: This assumes that items which should NEVER be predicted have score = -INF
%          Output:
%              precision: the fraction of predicted items which happen to be target items.
%              sensitivity: the fraction of target Items in the prediction.
%              specificity: the fraction of non-target items correctly excluded from the prediction.
%          Usage: refer test methods. Note: +statistics folder should be in the path.
        
    %      display('Checking prediction.')
        
        [sortedScoresTrimmed, sortedIndices] = statistics.ClassificationEvaluation.trimSortedScoresItems(numPredictions, sortedScoresAll, sortedIndicesAll);
        
        cutoff = sortedScoresTrimmed(end);
        firstElementInEq = find(sortedScoresTrimmed == cutoff, 1, 'first');
        eq = sortedIndices(firstElementInEq: end);
        gt = sortedIndices(1: firstElementInEq - 1);
        
        numIdentifiedPositives = full(sum(targetItemSet(gt)));
        numIdentifiedPositives = numIdentifiedPositives + full(sum(targetItemSet(eq)))*(numPredictions - numel(gt))/numel(eq);
        
    %      Called T in the document.
        numActualPositives = sum(targetItemSet);
        
    %      Called U in the document.
        numCandidateItems = numel(targetItemSet) - sum(sortedScoresAll == -Inf);
        
        numActualNegatives = numCandidateItems - sum(targetItemSet);
        numMisidentifiedPositives = numPredictions - numIdentifiedPositives;
        
        precision =  numIdentifiedPositives / numPredictions;
        
        sensitivity = numIdentifiedPositives/ numActualPositives;
        specificity = 1 - numMisidentifiedPositives/numActualNegatives;
        
    end
    
    function [scoreVector, sortedIndices] = trimSortedScoresItems(numPredictions, scoreVector, sortedIndices)
        cutoff = scoreVector(numPredictions);
    %      display('Found cutoff score')
        lastOccuranceOfCutoff = numPredictions - 1 + find(scoreVector(numPredictions: end) == cutoff, 1, 'last');
        sortedIndices = sortedIndices(1:lastOccuranceOfCutoff);
        scoreVector = scoreVector(1:lastOccuranceOfCutoff);
    end

    function testCheckPrediction()
        scoreVector = zeros(10,1);
        sortedIndices = (1:10);
        targetItemSet = zeros(10,1);
        targetItemSet([2, 3, 7]) = 1;
        numPredictions = 3;
        
        [precision, sensitivity, specificity] = statistics.ClassificationEvaluation.checkPrediction(scoreVector, sortedIndices, numPredictions, targetItemSet)
        fprintf(1, 'expected result: sensitivity: %d specificity: %d\n', numPredictions/ 10, 1 - numPredictions/ 10);
    end
    
    function [areaUnderCurve] = getAUCApprox(targetItemSet, scoreVector)
%          Description:
%              Suppose that you want to identify n (where n varies from 1 to N) items as belonging to a target set, using scores provided in scoreVector. How good is this series of predictions? To find out, one can calculate the the expected AUC (Area under the ROC curve) approximately by using a piecewise-linear function.
%              The logic is specified in the following:
%              'AUC from Scores' by nAgarAjan naTarAjan and vishvAs vAsuki. http://userweb.cs.utexas.edu/~vvasuki/work/statistics/AUCFromScores/AUCFromScores.pdf
%          WARNING: Minimal error checking. Please send valid inputs :-).
%          Input:
%              targetItemSet: logical vector. ith element is 1 if the ith item is in the target set, and 0 otherwise.
%              scoreVector: vector. the ith element corresponds to score of item i.
%          ASSUMPTION: This assumes that items which should NEVER be predicted have score = -INF
%          Output:
%              AUC.
%          Usage: refer test methods. Note: +statistics folder should be in the path.
            
        areaUnderCurve = 0;
        areaUnderCurveUpperBound = 0;
        areaUnderCurveLowerBound = 0;
        oldSpecificity = 1;
        oldSensitivity = 0;
        
        
        [sortedScoresAll sortedIndicesAll] = sort(full(scoreVector),'descend');
        maxNumPredictions = numel(targetItemSet) - sum(sortedScoresAll == -Inf);
        
        numTargetItems = full(sum(targetItemSet));
        for numPredictions = floor(linspace(1, maxNumPredictions, 50))
            [precision, sensitivity, specificity] = statistics.ClassificationEvaluation.checkPrediction(sortedScoresAll, sortedIndicesAll, numPredictions, targetItemSet);
%              fprintf (1, '%d %d %d \n', numPredictions, sensitivity, specificity);
            
            areaUnderCurveUpperBound = areaUnderCurveUpperBound + sensitivity*(oldSpecificity - specificity);
            areaUnderCurveLowerBound = areaUnderCurveLowerBound + oldSensitivity*(oldSpecificity - specificity);
            oldSpecificity = specificity;
            oldSensitivity = sensitivity;
        end
%          display 'All done  - ready for inspection!'
        areaUnderCurve = areaUnderCurveLowerBound;
        areaUnderCurve = (areaUnderCurveLowerBound + areaUnderCurveUpperBound)/2;
        
    end
    
    function [areaUnderCurve] = getAUC(targetItemSet, scoreVector)
%          Description:
%              Suppose that you want to identify n (where n varies from 1 to N) items as belonging to a target set, using scores provided in scoreVector. How good is this series of predictions? To find out, one can calculate the the expected AUC (Area under the ROC curve) exactly.
%              The logic is specified in the following:
%              'AUC from Scores' by nAgarAjan naTarAjan and vishvAs vAsuki. http://userweb.cs.utexas.edu/~vvasuki/work/statistics/AUCFromScores/AUCFromScores.pdf
%          WARNING: Minimal error checking. Please send valid inputs :-).
%          Input:
%              targetItemSet: logical vector. ith element is 1 if the ith item is in the target set, and 0 otherwise.
%              scoreVector: vector. the ith element corresponds to score of item i.
%          ASSUMPTION: This assumes that items which should NEVER be predicted have score = -INF
%          Output:
%              AUC.
%          Usage: refer test methods. Note: +statistics folder should be in the path. Eg: statistics.ClassificationEvaluation.getAUC(.,.)
        targetItemSet = logical(targetItemSet);
        uniqSortedTgtScores = unique(scoreVector(targetItemSet));
        numCandidateItems = numel(targetItemSet) - sum(scoreVector == -Inf);
        numTargetItems = sum(targetItemSet);
        areaUnderCurve = 0;
        for i=numel(uniqSortedTgtScores):-1:1
            score = uniqSortedTgtScores(i);
            
%              Interval of type A
            I_U = find(scoreVector == score);
            width = length(I_U);
            numI_T = sum(targetItemSet(I_U));
            sensitivity_I = sum(scoreVector(targetItemSet) > score)/numTargetItems;
            expectedCorrectIdentifications = numI_T*(width+1)/2;
            changeInAreaUnderCurve = sensitivity_I * width / numCandidateItems + (expectedCorrectIdentifications)/(numTargetItems*numCandidateItems);
            areaUnderCurve = areaUnderCurve + changeInAreaUnderCurve;
%              keyboard
%              fprintf(1, 'AUC so far: %d\n', areaUnderCurve);
            
%              Interval of type B
            if i == 1
                nextScore = -Inf;
            else
                nextScore = uniqSortedTgtScores(i-1);
            end
            I_U = find((scoreVector < score) & (scoreVector > nextScore));
            width = length(I_U);
            sensitivity_I = sum(scoreVector(targetItemSet) > nextScore)/numTargetItems;
%              keyboard
            changeInAreaUnderCurve = sensitivity_I * width / numCandidateItems;
            areaUnderCurve = areaUnderCurve + changeInAreaUnderCurve;
%              fprintf(1, 'AUC so far: %d\n', areaUnderCurve);
        end
    end
    
    
    function testGetAUC()
        numItems = 1000;
        scoreVector = zeros(numItems, 1);
        targetItemSet = zeros(numItems, 1);
        targetItemSet(5) = 1;
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUCApprox(targetItemSet, scoreVector)
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUC(targetItemSet, scoreVector)
        fprintf(1, 'expected AUC: %d\n', (numItems+1)/2/numItems);
        
        scoreVector(5) = 1;
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUCApprox(targetItemSet, scoreVector)
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUC(targetItemSet, scoreVector)
        fprintf(1, 'expected AUC: %d\n', 1);
        
        scoreVector(4) = 1;
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUCApprox(targetItemSet, scoreVector)
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUC(targetItemSet, scoreVector)
        fprintf(1, 'expected AUC: close to %d\n', 1);
    
        scoreVector(9) = 1;
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUCApprox(targetItemSet, scoreVector)
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUC(targetItemSet, scoreVector)
        fprintf(1, 'expected AUC: close to %d\n', 1);
    
        scoreVector(9:508) = 1;
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUCApprox(targetItemSet, scoreVector)
        [areaUnderCurve] = statistics.ClassificationEvaluation.getAUC(targetItemSet, scoreVector)
        fprintf(1, 'expected AUC: close to %d\n', 0.75);
    
    end
    
end
end