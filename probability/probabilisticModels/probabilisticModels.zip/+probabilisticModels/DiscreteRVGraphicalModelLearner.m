classdef DiscreteRVGraphicalModelLearner
methods(Static=true)
function negLogLikelihood = getNegLogLikelihood(sample, node, EdgeCouplings)
%   INPUTS:
%      EdgeCouplings: Size: numStates*numStates*numNodes.
%      Process inputs
    numStates = size(EdgeCouplings, 2);
    numNodes = size(EdgeCouplings, 3);
    
%      -\sum_{v \in V} EdgeCouplings_{sample(node), sample(v), node, v} + \sum_l log \sum_{v \in V}EdgeCouplings_{l, sample(v), node, v} 
    
    edgeCouplingsAllValues = [];
    for(n = 1:numNodes)
        edgeCouplingsAllValues = [edgeCouplingsAllValues; EdgeCouplings(:, sample(n), n)];
    end
    negLogLikelihood = - edgeCouplingsAllValues(sample(node)) + sum(log(exp(edgeCouplingsAllValues)));
end

function GradientNegLogLikelihood = getGradientNegLogLikelihood(sample, node, EdgeCouplings)
%      Process inputs
    [numStates, b, numNodes] = size(EdgeCouplings);
    
    GradientNegLogLikelihood = zeros(numStates, numStates, numNodes);
    allNodes = (1:numNodes)';
    
    for(n = 1:numNodes)
        if(n ~= node)
            GradientNegLogLikelihood(:, sample(n), n) = 1/numNodes;
            GradientNegLogLikelihood(sample(node), sample(n), n) = 0;
        end
    end
end

function totalGradientNegLogLikelihood = getTotalGradientNegLogLikelihood(Samples, node, edgeCouplingsVector, numStates)
    import probabilisticModels.*;
    
%      Process inputs
    [numNodes, numSamples] = size(Samples);
    EdgeCouplings = reshape(edgeCouplingsVector, numStates, numStates, numNodes);
    
    totalGradientNegLogLikelihood = zeros(numStates, numStates, numNodes);
    for i = 1:numSamples
        sample = Samples(:, i);
        totalGradientNegLogLikelihood = totalGradientNegLogLikelihood + DiscreteRVGraphicalModelLearner.getGradientNegLogLikelihood(sample, node, EdgeCouplings);
    end
    totalGradientNegLogLikelihood = totalGradientNegLogLikelihood(:);
%      EdgeCouplings
%      reshape(totalGradientNegLogLikelihood, size(EdgeCouplings))
end

function totalNegLogLikelihood = getTotalNegLogLikelihood(Samples, node, edgeCouplingsVector, numStates)
    import probabilisticModels.*;
    
%      Process inputs
    [numNodes, numSamples] = size(Samples);
    EdgeCouplings = reshape(edgeCouplingsVector, numStates, numStates, numNodes);
    
    totalNegLogLikelihood = 0;
    for i = 1:numSamples
        sample = Samples(:, i);
        totalNegLogLikelihood = totalNegLogLikelihood + DiscreteRVGraphicalModelLearner.getNegLogLikelihood(sample, node, EdgeCouplings);
    end
%      EdgeCouplings
    % totalNegLogLikelihood = totalNegLogLikelihood/numSamples
end

function NbdEdgeCoupling = getNbdEdgeCouplingFromSamples(Samples, node, numStates, groupL1Bound, groupL1penaltyType, NbdEdgeCoupling)
    import probabilisticModels.*;
    % Process inputs
    [numNodes, numSamples] = size(Samples);
    fprintf('Considering node %d.\n', node);
    if(isempty(groupL1penaltyType))
%          groupL1penaltyType = 'L1L_inf';
        groupL1penaltyType = 'L1L2';
    end
    
    totalNegLogLikelihoodFn = @(edgeCouplingsVector)DiscreteRVGraphicalModelLearner.getTotalNegLogLikelihood(Samples, node, edgeCouplingsVector, numStates);
    totalGradientNegLogLikelihoodFn = @(edgeCouplingsVector)DiscreteRVGraphicalModelLearner.getTotalGradientNegLogLikelihood(Samples, node, edgeCouplingsVector, numStates);
    funObj = @(edgeCouplingsVector)FunctionUtilities.combine2functions(totalNegLogLikelihoodFn, totalGradientNegLogLikelihoodFn, edgeCouplingsVector);
    
    groupIdentifiers = zeros(numStates, numStates, numNodes);
    for(n = 1:numNodes)
        groupIdentifiers(:, :, n) = n;
    end
    groupIdentifiers = groupIdentifiers(:);
    
    if(StringUtilities.isSubstring(groupL1penaltyType, 'inf'))
        fprintf('L1L_inf projection\n');
        projectorFn = @(edgeCouplingsVector)groupLinfProj(edgeCouplingsVector,groupL1Bound, groupIdentifiers);
    else
        fprintf('L1L2 projection\n');
        projectorFn = @(edgeCouplingsVector)groupL2Proj(edgeCouplingsVector,groupL1Bound, groupIdentifiers);
    end
    options = struct('verbose', 1);
    NbdEdgeCoupling(:) = minConF_PQN(funObj, NbdEdgeCoupling(:), projectorFn, options);
    
end

function [adjMatrix, EdgeCouplings] = graphFromSamples(Samples, numStates, groupL1Bound, edgeCouplingCutoff, groupL1penaltyType, EdgeCouplings)
    import probabilisticModels.*;
    numNodes = size(Samples, 1);
    adjMatrix = [];
    for(node = 1:numNodes)
        NbdEdgeCoupling = EdgeCouplings(:, :, :, node);
        NbdEdgeCoupling = DiscreteRVGraphicalModelLearner.getNbdEdgeCouplingFromSamples(Samples, node, numStates, groupL1Bound, groupL1penaltyType, NbdEdgeCoupling);
        EdgeCouplings(:, :, :, node) = NbdEdgeCoupling;
        adjMatrix(node, :) = DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, NbdEdgeCoupling, edgeCouplingCutoff);
%          NbdEdgeCoupling
%          keyboard
    end
    adjMatrix = sparse(adjMatrix);
end

function [probabilityOfSuccess] = getProbabilityOfSuccess(adjMatrixOriginal, NodePotentials, EdgePotentials, sampleBatches)
    import probabilisticModels.*;
    import graph.*;
    
    % process inputs
    numStates = size(EdgePotentials, 1);
    numEdgesOriginal = size(EdgePotentials, 3);
    numNodes = size(adjMatrixOriginal, 1);
    
    edgeCouplingCutoff = 0;
    groupL1Bound = 10^-2;
    groupL1penaltyType = 'L1L2';
%      groupL1penaltyType = 'L1L_inf';
    
    % Learn groupL1Bound
    EdgeCouplings = log(EdgePotentials);
    groupL1Bound = 0;
    for edge = 1:numEdgesOriginal
        edgeCouplingSize = norm(EdgeCouplings(:, :, edge), 'fro');
        groupL1Bound = max(edgeCouplingSize, groupL1Bound);
    end
    fprintf('groupL1Bound : %d\n', groupL1Bound);
    
    numSampleSets = length(sampleBatches);
    EdgeCouplings = zeros(numStates, numStates, numNodes, numNodes);
    numSuccesses = 0;
    for(sampleSet = 1:numSampleSets)
        Samples = sampleBatches{sampleSet};
        
        timer = Timer();
        % Learn graph
        [adjMatrix, EdgeCouplings] = DiscreteRVGraphicalModelLearner.graphFromSamples(Samples, numStates, groupL1Bound, edgeCouplingCutoff, groupL1penaltyType, EdgeCouplings);
        adjMatrix = logical(adjMatrix | adjMatrix');
        % adjMatrix = logical(adjMatrix & adjMatrix');
        % adjMatrix & adjMatrix' does not work as well as adjMatrix | adjMatrix'.
    
        % Evaluate
    %      display 'Matrix learned';
    %      sparse(adjMatrix)
    %      display 'Original Matrix';
    %      sparse(adjMatrixOriginal)
        timer.endTimer();
        
        [extraEdges, extraEdgesInOriginal] = Graph.getDifference(adjMatrix, adjMatrixOriginal);
        numEdges = Graph.getNumEdges(adjMatrix);
        fprintf('numEdges: %d, extraEdges: %d, extraEdgesInOriginal: %d\n', numEdges, extraEdges, extraEdgesInOriginal);
        if(extraEdges + extraEdgesInOriginal == 0)
            numSuccesses = numSuccesses + 1;
        end
        
    end
    
    probabilityOfSuccess = numSuccesses/ numSampleSets;
    
    fprintf('All done: ready for inspection!\n');
    keyboard
end

function testGraphFromSamples()
    import probabilisticModels.*;
    import graph.*;
    numStates = 3;
    degmax = [];
    numNodes = 64;
    numSampleSets = 1;
    
    % Get graph
    topology = 'chain';
    couplingType = 'uniform';
    [adjMatrixOriginal, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getDiscreteRVGraphicalModel(topology, numNodes, degmax, numStates, couplingType);
    
    % Get samples
    numSamples = 150;
    for sampleBatch = 1:numSampleSets
        bIsTree = Graph.isTree(topology);
        timer = Timer();
        Samples = DiscreteRVGraphicalModel.getSamples(adjMatrixOriginal, NodePotentials, EdgePotentials, bIsTree, numSamples);
        timer.endTimer();
        fprintf('Got %d samples! \n', numSamples);
        sampleBatches{sampleBatch} = Samples;
    end
    
    [probabilityOfSuccess] = DiscreteRVGraphicalModelLearner.getProbabilityOfSuccess(adjMatrixOriginal, NodePotentials, EdgePotentials, sampleBatches);
    
end

function testClass
    display 'Class definition is ok';
end

end
end
