classdef DiscreteRVGraphicalModel
methods(Static=true)
function Samples = getSamples(adjMatrix, NodePotentials, EdgePotentials, bIsTree, numSamples)
%   Sample using Mark Schmidt's UGM package. (http://www.cs.ubc.ca/~schmidtm/Software/UGM/small.html)
%   OUTPUT: Samples: numNodes * numSamples array of samples.
    numStates = size(NodePotentials, 2);
    edgeStruct = UGM_makeEdgeStruct(adjMatrix, numStates);
    if(bIsTree)
        display 'Tree sampling: using divide and conquer'
        edgeStruct.maxIter = numSamples;
        Samples = UGM_Sample_Tree(NodePotentials, EdgePotentials, edgeStruct);
    else
%          Samples = UGM_Sample_Exact(nodePot,edgePot,edgeStruct);
        display 'Approximate sampling: Gibbs'
        burnIn = 1000;
        edgeStruct.maxIter = numSamples;
        Samples = UGM_Sample_Gibbs(NodePotentials, EdgePotentials, edgeStruct, burnIn);
    end
end

function [adjMatrix, NodePotentials, EdgePotentials] = getDiscreteRVGraphicalModel(topology, numNodes, degmax, numStates, couplingType)
%      Process inputs
    if(isempty(couplingType))
        couplingType = 'normal';
    end
    
    import probabilisticModels.*;
    
    [adjMatrix, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates);
    numEdges = size(EdgePotentials, 3);
    
    for(edge = 1:numEdges)
        switch couplingType
            case 'normal'
                EdgePotentialTemplate = randn(numStates);
            case 'uniform'
                EdgePotentialTemplate = rand(numStates);
        end
        EdgePotentials(:, :, edge) = EdgePotentialTemplate;
    end
end

function [adjMatrix, NodePotentials, EdgePotentials] = getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates)
    if(isempty(degmax))
        degmax = (numNodes - 1);
    end
    
    adjMatrix = graph.Graph.getGraph(topology, numNodes, degmax);
    
    NodePotentials = ones(numNodes, numStates);
    
    
    numEdges = sum(sum(triu(adjMatrix)));
    EdgePotentials = ones(numStates, numStates, numEdges);
end

function [adjMatrix, NodePotentials, EdgePotentials] = getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType)
    import probabilisticModels.*;
    numStates = 2;
    
    [adjMatrix, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates);
    numEdges = size(EdgePotentials, 3);
    
    EdgePotentialTemplatePositive = 2.^(couplingStrength*[1 -1; -1 1]);
    EdgePotentialTemplateNegative = 2.^(couplingStrength*[-1 1; 1 -1]);
    
    EdgePotentialFractions = ones(1, numEdges);
    
    if(~isempty(findstr(topology, 'star')))
        rho = min(0.1,2.5/degmax);
        sig = eye(numNodes);
        for(s = 1:numNodes)
            if(adjMatrix(1,s) ~= 0)
                sig(1,s) = rho;
                sig(s,1) = rho;
                
                for(t = 1:numNodes)
                    if((t ~= s) && (adjMatrix(1,t) ~= 0))
                        sig(s,t) = rho^2;
                        sig(t,s) = rho^2;
                    end
                end
            end
        end
        EdgePotentialFractionsStar = adjMatrix.*inv(sig);
        EdgePotentialFractionsStar = EdgePotentialFractionsStar(1,:);
        EdgePotentialFractions = EdgePotentialFractionsStar(EdgePotentialFractionsStar ~= 0);
    end

    
    for(edge = 1:numEdges)
        switch couplingType
            case 'positive'
                EdgePotentialTemplate = EdgePotentialTemplatePositive;
            case 'negative'
                EdgePotentialTemplate = EdgePotentialTemplateNegative;
            case 'mixed'
                if(randomizationUtils.Sample.binaryRandomVariable())
                    EdgePotentialTemplate = EdgePotentialTemplatePositive;
                else
                    EdgePotentialTemplate = EdgePotentialTemplateNegative;
                end
        end
        EdgePotentials(:, :, edge) = EdgePotentialTemplate.^EdgePotentialFractions(edge);
    end
end

function adjMatrixRow = getNeighborsFromEdgeCouplings(node, EdgeCouplings, edgeCouplingCutoff)
%   INPUT: EdgeCouplings : numStates * numStates * numNodes matrix.
%      Process input
    
    numNodes = size(EdgeCouplings, 3);
    if(isempty(edgeCouplingCutoff))
        edgeCouplingCutoff = 10^-4;
    end
    adjMatrixRow = zeros(1, numNodes);
    for(j = 1:numNodes)
        % EdgeCouplings(:, :, j)
        if((node ~=j) && any(any(abs(EdgeCouplings(:, :, j)) > edgeCouplingCutoff)))
            adjMatrixRow(1, j) = 1;
        end
    end
end

function testGetBinaryRVGraphicalModel()
    import probabilisticModels.*;
    import graph.*;
    numNodes = 2;
    degmax = [];
    couplingStrength = 0.999;
    couplingType = 'negative';
    topology = 'chain';
    [adjMatrix, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType)
    
    numSamples = 15;
    
    bIsTree = Graph.isTree(topology);
    Samples = DiscreteRVGraphicalModel.getSamples(adjMatrix, NodePotentials, EdgePotentials, bIsTree, numSamples)
    
    fprintf('Expectation: In most samples, nodes connected by an edge disagree in value.');
    
    
end

function testClass
    display 'Class definition is ok';
end

end
end
